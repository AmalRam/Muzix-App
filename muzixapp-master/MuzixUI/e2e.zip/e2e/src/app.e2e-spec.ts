import { AppPage } from './app.po';
import {browser} from 'protractor';

describe('FrontEnd App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display Title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('MuzixUI');
  });
  
  it('testing Register Page', ()=> {
    page. clickSignUpModalSignUpButton();
    expect(browser.getCurrentUrl()).toEqual('http://localhost:4200/register');
  });

  it('testing BookMark  Page',()=> {
    page. clickNavMyBookmarkist();
    expect(browser.getCurrentUrl()).toEqual('http://localhost:4200/muzix/bookmark');
  });
  
  it('testing Suggest  Page',()=> {
    page.clickNavSuugestedMuzix();
    expect(browser.getCurrentUrl()).toEqual('http://localhost:4200/muzix/suggest');
  });

  

});
