
import { browser,by } from "protractor";
describe('Register Page Testing',function(){
it('To check the page title',function(){
  
    browser.get("http://localhost:4200/register").then(()=>(browser.getTitle())).then((title)=>(console.log(title)));
})
it('Register User', async()=>  {
    browser.get("http://localhost:4200/register");
    browser.driver.manage().window().maximize();
    //browser.findElement(by.partialLinkText('Register here')).click();
    browser.driver.sleep(4000); 
    browser.findElement(by.id('firstName')).sendKeys("test13");
    browser.findElement(by.id('lastName')).sendKeys("test13");
    browser.findElement(by.id('userId')).sendKeys("test13");
    browser.findElement(by.id('password')).sendKeys("test13");
    //browser.findElement(by.xpath('/html/body/app-root/app-register/form/div/div[3]/button[1]/span')).click();
   browser.findElement(by.id('register')).click(); 
    browser.sleep(2000);
    expect(browser.getCurrentUrl()).toEqual('http://localhost:4200/login');
    browser.driver.sleep(5000);
   })


   it('Registering with exiting credentials ', async()=>  {
    browser.get("http://localhost:4200/register");
    browser.driver.manage().window().maximize();
    //browser.findElement(by.partialLinkText('Register here')).click();
    browser.driver.sleep(4000); 
    browser.findElement(by.id('firstName')).sendKeys("test13");
    browser.findElement(by.id('lastName')).sendKeys("test13");
    browser.findElement(by.id('userId')).sendKeys("test13");
    browser.findElement(by.id('password')).sendKeys("test13");
    browser.findElement(by.xpath('/html/body/app-root/app-register/form/div/div[3]/button[1]/span')).click();
    expect<any>(browser.getCurrentUrl()).toEqual('http://localhost:4200/register');
    browser.driver.sleep(5000);
   })
})